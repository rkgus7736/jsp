package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ModelAndView;

public class LoginController {
	
	public ModelAndView execute(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView view = new ModelAndView();
		
		return view;
	}
}
